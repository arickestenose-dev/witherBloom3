"""Texturas, modelos JSON y lang de items, bloques, armaduras y efectos."""
import os, json, math, random, zlib
from wbart import *

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
A = f'{ROOT}/src/main/resources/assets/witherbloom'
for d in ('textures/item', 'textures/block', 'textures/models/armor', 'textures/mob_effect', 'models/item', 'models/block', 'blockstates', 'lang'):
    os.makedirs(f'{A}/{d}', exist_ok=True)

def save(img, path): img.save(f'{A}/{path}')
def jdump(path, obj):
    with open(f'{A}/{path}', 'w') as fh: json.dump(obj, fh, indent=2, ensure_ascii=False)
C = hexc
STEEL, STEEL_D, STEEL_L = C('#9aa0aa'), C('#5a606b'), C('#d6dae2')
GOLD, WOOD, WOOD_L = C('#e0b43a'), C('#6b4a2a'), C('#8a6238')
PURPLE, PINK, CYAN, RED = C('#7B3FBF'), C('#ff6fc2'), C('#5ff2e0'), C('#d02a40')

# ------------------------------------------------------------------ iconos de armas y herramientas
def handle(img, a=(2, 14), b=(10, 6)):
    line(img, a, b, WOOD); line(img, (a[0] + 1, a[1]), (b[0] + 1, b[1]), WOOD_L)

def sword(blade, guard, tip=(13, 2), base=(6, 9), glow=None, length_extra=0):
    img = new_img(16, 16)
    line(img, (2, 14), (5, 11), WOOD); line(img, (3, 14), (5, 12), WOOD_L)
    line(img, (3, 8), (8, 13), guard) if guard else None
    line(img, base, tip, blade[0]); line(img, (base[0] + 1, base[1]), (tip[0] + 1 if tip[0] < 15 else tip[0], tip[1]), blade[1])
    if glow: px(img, [(9, 6), (11, 4)], glow)
    return img

def estoque():
    img = sword((STEEL_L, STEEL), GOLD)
    rect(img, 4, 9, 5, 10, GOLD); px(img, [(5, 10)], C('#7a5a10'))   # candado en la guarda
    return img
def daga():
    img = new_img(16, 16)
    line(img, (3, 13), (5, 11), WOOD); line(img, (4, 13), (5, 12), WOOD_L)
    line(img, (4, 9), (8, 13), PURPLE)
    line(img, (6, 9), (12, 3), C('#7ff3ee')); line(img, (7, 9), (13, 4), C('#35c6c8')); px(img, [(10, 5)], C('#ffffff'))
    return img
def hacha_hueso():
    img = new_img(16, 16); handle(img)
    px(img, [(8, 2), (9, 2), (10, 2), (7, 3), (8, 3), (9, 3), (10, 3), (11, 3), (7, 4), (8, 4), (9, 4), (10, 4), (11, 4), (12, 4), (8, 5), (9, 5), (10, 5), (11, 5), (12, 5), (9, 6), (10, 6)], C('#2c2c36'))
    px(img, [(7, 3), (7, 4), (8, 2), (12, 5), (12, 4)], C('#e8e2cc'))
    return img
def guadana():
    img = new_img(16, 16); handle(img, (2, 14), (10, 6))
    px(img, [(11, 5), (12, 4), (12, 3), (11, 2), (10, 2), (9, 2), (8, 2), (7, 3), (6, 3)], C('#35b6ff'))
    px(img, [(11, 4), (11, 3), (10, 3), (9, 3), (8, 3)], C('#1a1a24'))
    return img
def lanza():
    img = new_img(16, 16); handle(img, (1, 15), (11, 5))
    px(img, [(12, 4), (13, 3), (13, 2), (12, 3), (14, 2), (14, 1)], CYAN); px(img, [(12, 5), (11, 4), (13, 4)], PINK)
    px(img, [(10, 6), (9, 7)], PURPLE)
    return img
def baston():
    img = new_img(16, 16); handle(img, (2, 14), (10, 6))
    disc(img, 11, 4, 2.2, C('#e0405a')); px(img, [(10, 3), (11, 3)], C('#ffb0b8'))
    px(img, [(8, 4), (14, 4), (11, 1), (11, 7), (9, 2), (13, 6)], C('#ff8fa0'))
    return img
def jeringa():
    img = new_img(16, 16)
    line(img, (5, 11), (10, 6), C('#e9ecef')); line(img, (4, 11), (9, 6), C('#e9ecef')); line(img, (5, 10), (9, 6), C('#6ad66a'))
    line(img, (11, 5), (14, 2), STEEL_L)
    line(img, (3, 13), (1, 15), STEEL); line(img, (3, 11), (6, 14), STEEL_D)
    return img
def pico():
    img = new_img(16, 16); handle(img)
    px(img, [(4, 4), (5, 3), (6, 2), (7, 2), (8, 2), (9, 2), (10, 3), (11, 4), (12, 5), (5, 4), (6, 3), (7, 3), (8, 3), (9, 3), (10, 4), (11, 5)], C('#3d3d48'))
    px(img, [(9, 3), (10, 4), (4, 4), (12, 5)], PURPLE)
    return img
def podadora():
    img = new_img(16, 16); handle(img)
    px(img, [(7, 2), (8, 2), (9, 3), (10, 3), (6, 3), (7, 3), (8, 3), (7, 4), (8, 4), (9, 4), (10, 4), (9, 5), (10, 5), (11, 4)], C('#4fae4a'))
    px(img, [(6, 3), (11, 4), (10, 5)], RED); px(img, [(8, 2), (9, 3)], C('#9be28a'))
    return img
def pala():
    img = new_img(16, 16); handle(img, (2, 14), (11, 5))
    px(img, [(11, 2), (12, 2), (10, 3), (11, 3), (12, 3), (13, 3), (10, 4), (11, 4), (12, 4), (13, 4), (11, 5), (12, 5), (12, 6)], C('#8a8a93'))
    px(img, [(10, 3), (10, 4), (11, 2)], C('#c1c1c9')); px(img, [(12, 5)], C('#d98a2a'))
    return img
def azada():
    img = new_img(16, 16); handle(img)
    px(img, [(8, 3), (9, 2), (10, 2), (11, 2), (12, 3), (12, 4), (9, 3), (10, 3), (11, 3), (8, 4)], C('#4fe0e8'))
    px(img, [(9, 2), (10, 2), (8, 3)], C('#d6ffff')); px(img, [(12, 4), (12, 3)], C('#1f9aa8'))
    return img
def tijeras():
    img = new_img(16, 16)
    line(img, (3, 3), (11, 11), C('#5fd6ee')); line(img, (4, 3), (12, 11), C('#bff6ff'))
    line(img, (12, 3), (4, 11), C('#5fd6ee')); line(img, (11, 3), (3, 11), C('#bff6ff'))
    disc(img, 3, 13, 1.6, C('#3a8fb0')); disc(img, 12, 13, 1.6, C('#3a8fb0')); px(img, [(3, 13), (12, 13)], (0, 0, 0, 0))
    return img
def arco(pull):
    img = new_img(16, 16)
    pts = []
    for i in range(0, 31):
        t = math.pi / 2 + i * (math.pi / 2) / 30
        pts.append((round(12 + 9 * math.cos(t)), round(12 - 9 * math.sin(t))))
    px(img, pts, C('#3f8f3a')); px(img, [(x + 1, y) for x, y in pts[4:-4]], C('#6bc260'))
    px(img, [(p[0], p[1]) for i, p in enumerate(pts) if i % 7 == 3], RED)
    mid = {0: (7, 7), 1: (9, 9), 2: (10, 10)}.get(pull)
    if mid is None: line(img, pts[0], pts[-1], C('#e8e8e8'))
    else:
        line(img, pts[0], mid, C('#e8e8e8')); line(img, mid, pts[-1], C('#e8e8e8'))
        line(img, mid, (mid[0] + 3, mid[1] + 3), C('#9be28a')) if pull else None
    return img

# ------------------------------------------------------------------ materiales
def m_hueso():
    img = new_img(16, 16); line(img, (4, 11), (11, 4), C('#2c2c36')); line(img, (5, 11), (12, 4), C('#3d3d48'))
    for (x, y) in ((3, 12), (4, 13), (12, 3), (13, 2)): disc(img, x, y, 1.3, C('#e8e2cc'))
    return img
def m_fibra():
    img = new_img(16, 16)
    for k, col in enumerate(('#2f7d32', '#4fae4a', '#7ad56a')):
        for t in range(14):
            px(img, [(3 + t + (k - 1) * 0, 13 - t + k + int(1.6 * math.sin(t / 2.0 + k)))], C(col))
            px(img, [(4 + t, 13 - t + k + int(1.6 * math.sin(t / 2.0 + k)))], C(col))
    px(img, [(6, 9), (9, 6)], RED); return img
def m_cristal_vivo():
    img = new_img(16, 16)
    px(img, [(x, y) for y, (a, b) in enumerate([(6, 9), (5, 10), (4, 11), (4, 11), (4, 11), (5, 10), (6, 9), (7, 8)], start=3) for x in range(a, b + 1)], C('#2fd4c4'))
    rect(img, 6, 6, 9, 9, C('#7ff3ee')); px(img, [(7, 7), (8, 7)], C('#ffffff')); px(img, [(10, 9), (10, 10), (9, 10)], C('#1a8f88'))
    return img
def m_tejido():
    img = new_img(16, 16); rect(img, 2, 2, 13, 13, C('#14181f'))
    rnd = random.Random(5)
    for _ in range(14): px(img, [(rnd.randint(3, 12), rnd.randint(3, 12))], C('#22e6d4'))
    px(img, [(4, 4), (11, 11), (8, 8)], C('#9ffcf4')); return img
def m_escombro():
    img = new_img(16, 16)
    for (cx, cy, r, c) in ((6, 10, 3.2, '#7a5230'), (11, 10, 2.8, '#664328'), (8, 6, 2.8, '#8f6038')): disc(img, cx, cy, r, C(c))
    px(img, [(5, 9), (9, 5), (11, 9), (7, 11)], C('#ff9a2a')); return img
def m_chapa():
    img = new_img(16, 16); rect(img, 2, 3, 13, 12, C('#8a909b')); rect(img, 2, 10, 13, 12, C('#e0b43a'))
    for x in range(2, 14, 3): px(img, [(x, 10), (x + 1, 11), (x + 2, 12)], C('#1a1a1a'))
    px(img, [(3, 5), (12, 5), (3, 8), (12, 8)], C('#4b4f58')); return img
def m_estrella():
    img = new_img(16, 16)
    for (x0, y0, x1, y1) in ((8, 1, 8, 14), (2, 6, 14, 6), (4, 3, 12, 11), (12, 3, 4, 11)): line(img, (x0, y0), (x1, y1), PINK)
    rect(img, 6, 6, 9, 9, C('#fff0fa')); px(img, [(7, 7), (8, 8)], C('#ffffff')); return img
def m_cristal_grieta():
    img = new_img(16, 16)
    px(img, [(x, y) for y in range(2, 14) for x in range(7 - min(y - 2, 13 - y, 3), 9 + min(y - 2, 13 - y, 3))], C('#6a2fb4'))
    px(img, [(8, y) for y in range(3, 13)], C('#a07af0')); px(img, [(5, 8), (6, 8), (10, 8), (11, 8)], C('#ff6fc2')); px(img, [(8, 8)], C('#ffffff')); return img
def m_nucleo():
    img = new_img(16, 16); disc(img, 8, 8, 6, C('#4b4f58')); disc(img, 8, 8, 4.2, C('#c8203a'))
    disc(img, 8, 8, 2.2, C('#ff7a8a')); px(img, [(7, 7)], C('#ffffff'))
    px(img, [(8, 1), (8, 14), (1, 8), (14, 8)], C('#9aa0aa')); return img

def m_tarjeta():
    img = new_img(16, 16); rect(img, 2, 4, 13, 12, C('#e9ecef')); rect(img, 2, 4, 13, 6, C('#4b4f58'))
    rect(img, 3, 8, 6, 10, C('#e0b43a')); rect(img, 8, 8, 12, 8, C('#9aa0aa')); rect(img, 8, 10, 11, 10, C('#9aa0aa')); px(img, [(12, 5)], C('#d02a40'))
    return img

ITEMS = {
    'hueso_negro': m_hueso, 'fibra_marchita': m_fibra, 'cristal_vivo': m_cristal_vivo, 'tejido_sculk': m_tejido,
    'escombro_de_mina': m_escombro, 'chapa_de_contencion': m_chapa, 'fragmento_estrella': m_estrella,
    'cristal_grieta': m_cristal_grieta, 'nucleo_prototipo': m_nucleo, 'tarjeta_de_acceso': m_tarjeta,
    'estoque_de_reja': estoque, 'daga_de_eco': daga, 'hacha_de_hueso_negro': hacha_hueso, 'guadana_de_wither': guadana,
    'lanza_de_asta': lanza, 'baston_de_plasma': baston, 'jeringa_de_antidoto': jeringa,
    'pico_sordo': pico, 'podadora_de_zarza': podadora, 'pala_de_escombro': pala, 'azada_purificadora': azada, 'tijeras_de_cristal': tijeras,
}

# ------------------------------------------------------------------ armaduras
SETS = {
    'reja': dict(main='#8c9099', dark='#4b4f58', light='#c3c7cf', acc='#e0b43a',
        head=[(1, 2, 1, 4, '#4b4f58'), (3, 2, 1, 4, '#4b4f58'), (5, 2, 1, 4, '#4b4f58'), (1, 4, 1, 1, '#d02020'), (6, 4, 1, 1, '#d02020')],
        chest=[(1, 1, 1, 9, '#4b4f58'), (3, 1, 1, 9, '#4b4f58'), (5, 1, 1, 9, '#4b4f58'), (3, 4, 2, 3, '#e0b43a'), (4, 5, 1, 1, '#7a5a10')]),
    'perforador': dict(main='#2b2b30', dark='#141417', light='#4a4a52', acc='#ffb43a',
        head=[(3, 0, 2, 2, '#ffb43a'), (3, 3, 2, 1, '#9aa0a8'), (1, 4, 6, 1, '#141417')],
        chest=[(0, 10, 8, 1, '#ffb43a'), (3, 3, 2, 2, '#d04030'), (1, 6, 6, 1, '#4a4a52')]),
    'zarza': dict(main='#3f7d3a', dark='#245523', light='#6fb85a', acc='#b0243a',
        head=[(0, 0, 1, 1, '#b0243a'), (7, 0, 1, 1, '#b0243a'), (1, 4, 6, 1, '#245523'), (2, 3, 1, 1, '#ffe04a'), (5, 3, 1, 1, '#ffe04a')],
        chest=[(1, 2, 1, 1, '#b0243a'), (6, 5, 1, 1, '#b0243a'), (3, 8, 1, 1, '#b0243a'), (2, 0, 1, 12, '#245523'), (5, 0, 1, 12, '#245523')]),
    'latiente': dict(main='#2fb5c9', dark='#17727f', light='#8ff0ff', acc='#d02a40',
        head=[(1, 3, 6, 2, '#0e4c58'), (2, 3, 1, 1, '#8ff0ff')],
        chest=[(3, 3, 2, 3, '#d02a40'), (3, 4, 1, 1, '#ff8a9a'), (1, 8, 6, 1, '#17727f')]),
    'asta': dict(main='#6a3fb0', dark='#3a2270', light='#a07af0', acc='#5ff2e0',
        head=[(1, 3, 6, 2, '#22123f'), (2, 3, 1, 1, '#ff6fc2'), (5, 3, 1, 1, '#ff6fc2'), (0, 0, 1, 3, '#5ff2e0'), (7, 0, 1, 3, '#5ff2e0')],
        chest=[(3, 3, 2, 2, '#ff6fc2'), (0, 0, 1, 12, '#5ff2e0'), (7, 0, 1, 12, '#5ff2e0')]),
    'neural': dict(main='#26262c', dark='#111114', light='#4a4a54', acc='#e02a3a',
        head=[(0, 3, 8, 1, '#e02a3a'), (3, 3, 2, 1, '#ffb0b0')], chest=[(0, 4, 8, 2, '#e02a3a'), (3, 4, 2, 2, '#ffb0b0'), (1, 8, 6, 1, '#4a4a54')]),
    'hermetico': dict(main='#e8c63a', dark='#a8861a', light='#fff08a', acc='#3a8fe0',
        head=[(1, 2, 6, 3, '#3a8fe0'), (1, 2, 2, 1, '#bfe4ff')],
        chest=[(0, 6, 8, 1, '#a8861a'), (2, 2, 4, 2, '#d04030')], chest_back=[(2, 1, 4, 8, '#8a8f99'), (3, 2, 2, 1, '#e0e4ea')]),
    'manto_eco': dict(main='#6fd0ee', dark='#3a8fb0', light='#dff8ff', acc='#ffffff', alpha=190,
        head=[(1, 3, 6, 3, '#10303c'), (2, 4, 1, 1, '#9ffcf4'), (5, 4, 1, 1, '#9ffcf4')],
        chest=[(3, 2, 2, 2, '#ffffff'), (0, 9, 8, 1, '#3a8fb0')]),
    'diagnostico': dict(main='#eceff2', dark='#a8adb5', light='#ffffff', acc='#41e07a',
        head=[(1, 2, 6, 4, '#10261a'), (2, 3, 4, 1, '#41e07a'), (2, 5, 3, 1, '#41e07a')], chest=[]),
}
HAS = {k: ('helmet', 'chestplate', 'leggings', 'boots') for k in SETS}
HAS['manto_eco'] = ('helmet', 'chestplate'); HAS['diagnostico'] = ('helmet',)

def armor_layers(name, s):
    rnd = random.Random(zlib.crc32(name.encode()))
    a = s.get('alpha', 255)
    main = hexc(s['main'], a)
    l1 = new_img(64, 32)
    paint_box(l1, 0, 0, 8, 8, 8, main, rnd, {'front': s['head'], 'top': [(0, 0, 8, 1, s['light'])]})
    paint_box(l1, 16, 16, 8, 12, 4, main, rnd, {'front': s['chest'], 'back': s.get('chest_back', [])})
    paint_box(l1, 40, 16, 4, 12, 4, main, rnd, {'top': [(0, 0, 4, 1, s['light'])], 'front': [(0, 9, 4, 1, s['dark'])]})
    paint_box(l1, 0, 16, 4, 12, 4, shade(main, 0.9), rnd, {'front': [(0, 9, 4, 1, s['dark']), (0, 10, 4, 2, s['dark'])]}, rows=(7, 12))
    save(l1, f'textures/models/armor/{name}_layer_1.png')
    if 'leggings' in HAS[name]:
        l2 = new_img(64, 32)
        paint_box(l2, 16, 16, 8, 12, 4, main, rnd, {'front': [(0, 3, 8, 1, s['dark']), (3, 1, 2, 2, s['light'])]}, rows=(0, 4))
        paint_box(l2, 0, 16, 4, 12, 4, shade(main, 0.95), rnd, {'front': [(0, 5, 4, 1, s['dark'])]})
        save(l2, f'textures/models/armor/{name}_layer_2.png')

def armor_icon(piece, s):
    img = new_img(16, 16); a = s.get('alpha', 255)
    m, d, l, ac = hexc(s['main'], a), hexc(s['dark'], a), hexc(s['light'], a), hexc(s['acc'], a)
    if piece == 'helmet':
        for r in ((4, 2, 11, 3), (3, 4, 12, 9), (3, 10, 5, 12), (10, 10, 12, 12)): rect(img, *r, m)
        rect(img, 5, 7, 10, 10, d); rect(img, 6, 8, 9, 8, ac); rect(img, 4, 3, 11, 3, l)
    elif piece == 'chestplate':
        for r in ((1, 2, 4, 7), (11, 2, 14, 7), (4, 2, 11, 14)): rect(img, *r, m)
        rect(img, 6, 2, 9, 3, (0, 0, 0, 0)); rect(img, 4, 14, 11, 14, d); rect(img, 7, 6, 8, 9, ac); rect(img, 1, 2, 4, 3, l); rect(img, 11, 2, 14, 3, l)
    elif piece == 'leggings':
        for r in ((3, 2, 12, 5), (3, 6, 7, 14), (8, 6, 12, 14)): rect(img, *r, m)
        rect(img, 3, 4, 12, 4, d); rect(img, 7, 6, 8, 14, (0, 0, 0, 0)); rect(img, 7, 3, 8, 4, ac)
    else:
        for r in ((2, 7, 6, 12), (1, 12, 6, 13), (9, 7, 13, 12), (8, 12, 14, 13)): rect(img, *r, m)
        rect(img, 1, 13, 6, 13, d); rect(img, 8, 13, 14, 13, d); rect(img, 2, 7, 6, 8, l); rect(img, 9, 7, 13, 8, l)
    finish_icon(img)
    return img

# ------------------------------------------------------------------ bloques
def block_tex(kind):
    rnd = random.Random(zlib.crc32(kind.encode())); img = new_img(16, 16)
    def fill(base, n=0.08):
        for y in range(16):
            for x in range(16): img.putpixel((x, y), shade(C(base), 1 + (rnd.random() - 0.5) * 2 * n))
    if kind == 'piedra_venosa':
        fill('#7d7f85')
        for _ in range(5):
            x, y = rnd.randint(0, 15), rnd.randint(0, 15)
            for t in range(rnd.randint(4, 8)):
                col = '#a82838' if rnd.random() < 0.6 else '#7B3FBF'
                px(img, [(x, y)], C(col)); x = (x + rnd.choice((0, 1, 1))) % 16; y = (y + rnd.choice((-1, 0, 1, 1))) % 16
    elif kind == 'hueso_negro_bloque':
        fill('#1f1f26')
        for y in (2, 7, 12): rect(img, 1, y, 14, y + 1, C('#d8d2bc')); px(img, [(0, y), (15, y + 1)], C('#d8d2bc'))
        rect(img, 7, 0, 8, 15, C('#2c2c36'))
    elif kind == 'fibra_marchita_bloque':
        fill('#3f7d3a', 0.06)
        for y in range(0, 16, 4):
            for x in range(16): px(img, [(x, y + (x % 2))], C('#245523')); px(img, [(x, y + 2 - (x % 2))], C('#6fb85a'))
    elif kind == 'cristal_vivo_bloque':
        fill('#2fd4c4', 0.05)
        line(img, (0, 8), (8, 0), C('#8ff7ee')); line(img, (2, 15), (15, 2), C('#8ff7ee')); line(img, (7, 15), (15, 7), C('#1a8f88'))
        rect(img, 5, 5, 10, 10, C('#69e8de')); px(img, [(6, 6), (7, 6)], C('#ffffff'))
    elif kind == 'tejido_sculk_bloque':
        fill('#12161d', 0.12)
        for _ in range(18): px(img, [(rnd.randint(0, 15), rnd.randint(0, 15))], C('#22e6d4'))
        for _ in range(4): px(img, [(rnd.randint(0, 15), rnd.randint(0, 15))], C('#b8fff8'))
    elif kind == 'escombro_de_mina_bloque':
        fill('#6e4a2c', 0.14)
        for _ in range(22): rect(img, (a := rnd.randint(0, 14)), (b := rnd.randint(0, 14)), a + 1, b + 1, shade(C('#6e4a2c'), rnd.choice((0.7, 1.25))))
        for _ in range(7): px(img, [(rnd.randint(0, 15), rnd.randint(0, 15))], C('#ff9a2a'))
    elif kind == 'chapa_de_contencion_bloque':
        fill('#8a909b', 0.04); rect(img, 0, 12, 15, 15, C('#e0b43a'))
        for x in range(-4, 16, 4):
            for t in range(4): px(img, [(x + t, 12 + t)], C('#1a1a1a')); px(img, [(x + t + 1, 12 + t)], C('#1a1a1a'))
        for (x, y) in ((1, 1), (14, 1), (1, 10), (14, 10)): px(img, [(x, y)], C('#4b4f58'))
        rect(img, 0, 0, 15, 0, C('#b4bac4')); rect(img, 0, 0, 0, 11, C('#b4bac4'))
    elif kind == 'bloque_de_antidoto':
        fill('#e9edf0', 0.03); rect(img, 6, 2, 9, 13, C('#3fbf5a')); rect(img, 2, 6, 13, 9, C('#3fbf5a'))
        rect(img, 7, 3, 8, 12, C('#8cf0a0')); rect(img, 3, 7, 12, 8, C('#8cf0a0')); rect(img, 0, 0, 15, 0, C('#bfc8cf')); rect(img, 0, 15, 15, 15, C('#bfc8cf'))
    elif kind == 'bloque_de_latido':
        fill('#8c2030', 0.1)
        for _ in range(8): px(img, [(rnd.randint(0, 15), rnd.randint(0, 15))], C('#5a0f1c'))
        line(img, (0, 3), (6, 7), C('#c8384a')); line(img, (15, 12), (9, 9), C('#c8384a'))
        disc(img, 8, 8, 3.4, C('#ff3a52')); disc(img, 8, 8, 1.8, C('#ffb0b8'))
    return img

BLOCKS = ['piedra_venosa', 'hueso_negro_bloque', 'fibra_marchita_bloque', 'cristal_vivo_bloque', 'tejido_sculk_bloque',
          'escombro_de_mina_bloque', 'chapa_de_contencion_bloque', 'bloque_de_antidoto', 'bloque_de_latido']

# ------------------------------------------------------------------ efectos
def effect_icons():
    img = new_img(18, 18); disc(img, 9, 8, 6.5, C('#2a2a33')); rect(img, 6, 13, 12, 16, C('#2a2a33'))
    rect(img, 5, 6, 7, 8, C('#35b6ff')); rect(img, 11, 6, 13, 8, C('#35b6ff')); px(img, [(9, 10), (8, 10)], C('#0a0a0e'))
    for x in (7, 9, 11): px(img, [(x, 14), (x, 15)], C('#e8e2cc'))
    finish_icon(img); save(img, 'textures/mob_effect/marchita.png' if False else 'textures/mob_effect/marchitez.png')
    img = new_img(18, 18); disc(img, 9, 9, 7, C('#9a2038')); disc(img, 9, 9, 5, C('#c83a5a'))
    line(img, (6, 3), (9, 8), C('#1a0408')); line(img, (9, 8), (7, 12), C('#1a0408')); line(img, (9, 8), (13, 10), C('#1a0408')); line(img, (7, 12), (9, 15), C('#1a0408'))
    finish_icon(img); save(img, 'textures/mob_effect/vulnerable.png')

# ------------------------------------------------------------------ lang
NAMES = {
 'hueso_negro': ('Hueso Negro', 'Black Bone'), 'fibra_marchita': ('Fibra Marchita', 'Withered Fiber'),
 'cristal_vivo': ('Cristal Vivo', 'Living Crystal'), 'tejido_sculk': ('Tejido Sculk', 'Sculk Tissue'),
 'escombro_de_mina': ('Escombro de Mina', 'Mine Rubble'), 'chapa_de_contencion': ('Chapa de Contención', 'Containment Plate'),
 'fragmento_estrella': ('Fragmento de Estrella', 'Star Fragment'), 'cristal_grieta': ('Cristal de Grieta', 'Rift Crystal'),
 'nucleo_prototipo': ('Núcleo Prototipo', 'Prototype Core'), 'tarjeta_de_acceso': ('Tarjeta de Acceso', 'Access Card'),
 'estoque_de_reja': ('Estoque de Reja', 'Gate Rapier'), 'daga_de_eco': ('Daga de Eco', 'Echo Dagger'), 'arco_viral': ('Arco Viral', 'Viral Bow'),
 'hacha_de_hueso_negro': ('Hacha de Hueso Negro', 'Black Bone Axe'), 'guadana_de_wither': ('Guadaña de Wither', 'Wither Scythe'),
 'lanza_de_asta': ('Lanza de Asta', 'Antler Spear'), 'baston_de_plasma': ('Bastón de Plasma', 'Plasma Staff'),
 'jeringa_de_antidoto': ('Jeringa de Antídoto', 'Antidote Syringe'),
 'pico_sordo': ('Pico Sordo', 'Muffled Pickaxe'), 'podadora_de_zarza': ('Podadora de Zarza', 'Bramble Pruner'),
 'pala_de_escombro': ('Pala de Escombro', 'Rubble Shovel'), 'azada_purificadora': ('Azada Purificadora', 'Purifying Hoe'),
 'tijeras_de_cristal': ('Tijeras de Cristal', 'Crystal Shears'),
 'piedra_venosa': ('Piedra Venosa', 'Veined Stone'), 'hueso_negro_bloque': ('Bloque de Hueso Negro', 'Black Bone Block'),
 'fibra_marchita_bloque': ('Bloque de Fibra Marchita', 'Withered Fiber Block'), 'cristal_vivo_bloque': ('Bloque de Cristal Vivo', 'Living Crystal Block'),
 'tejido_sculk_bloque': ('Bloque de Tejido Sculk', 'Sculk Tissue Block'), 'escombro_de_mina_bloque': ('Bloque de Escombro de Mina', 'Mine Rubble Block'),
 'chapa_de_contencion_bloque': ('Chapa de Contención', 'Containment Plate Block'),
 'bloque_de_antidoto': ('Bloque de Antídoto', 'Antidote Block'), 'bloque_de_latido': ('Bloque de Latido', 'Heartbeat Block'),
}
SET_NAMES = {'reja': ('Reja', 'Gate'), 'perforador': ('Perforador', 'Driller'), 'zarza': ('Zarza', 'Bramble'), 'latiente': ('Latiente', 'Beating'),
             'asta': ('Asta', 'Antler'), 'neural': ('Neural', 'Neural'), 'hermetico': ('Hermético', 'Hermetic'),
             'manto_eco': ('Manto de Eco', 'Echo Cloak'), 'diagnostico': ('Casco Diagnóstico', 'Diagnostic Helmet')}
PIECE = {'helmet': ('Casco', 'Helmet'), 'chestplate': ('Peto', 'Chestplate'), 'leggings': ('Grebas', 'Leggings'), 'boots': ('Botas', 'Boots')}
MOB_NAMES = {'chinche_carmesi': ('Chinche Carmesí', 'Crimson Bug'), 'antena_viva': ('Antena Viva', 'Living Antenna'), 'hinchado': ('Hinchado', 'Bloated'),
             'hiena_escarlata': ('Hiena Escarlata', 'Scarlet Hyena'), 'esqueleto_marchito': ('Esqueleto Marchito', 'Withered Skeleton'),
             'suplantador': ('Suplantador', 'Impostor'), 'guardian_de_la_reja': ('Guardián de la Reja', 'Gate Guardian'), 'topo_ciego': ('Topo Ciego', 'Blind Mole'),
             'mena_mimica': ('Mena Mímica', 'Mimic Ore'), 'capataz_micelio': ('Capataz Micelio', 'Mycelium Foreman'),
             'sanguijuela_cegadora': ('Sanguijuela Cegadora', 'Blinding Leech')}
STAGES = {'espora': ('Espora', 'Spore'), 'portador': ('Portador', 'Carrier'), 'colonia': ('Colonia', 'Colony'), 'apex': ('Apex', 'Apex'), 'caida': ('Caída', 'Fallen')}

def lang():
    es, en = {}, {}
    def put(k, pair): es[k], en[k] = pair
    for k, pair in NAMES.items():
        kind = 'block' if k in BLOCKS else 'item'
        put(f'{kind}.witherbloom.{k}', pair)
    for s, pair in SET_NAMES.items():
        for p in HAS[s]:
            if s in ('manto_eco', 'diagnostico'):
                nm = (pair[0] if p != 'helmet' or s == 'diagnostico' else 'Capucha de Eco', pair[1] if p != 'helmet' or s == 'diagnostico' else 'Echo Hood')
                if s == 'manto_eco' and p == 'chestplate': nm = ('Manto de Eco', 'Echo Cloak')
            else:
                nm = (f'{PIECE[p][0]} de {pair[0]}' if s in ('reja', 'perforador', 'zarza', 'asta') else f'{PIECE[p][0]} {pair[0]}', f'{pair[1]} {PIECE[p][1]}')
            put(f'item.witherbloom.{s}_{p}', nm)
    for m, pair in MOB_NAMES.items():
        put(f'entity.witherbloom.{m}', pair)
        put(f'item.witherbloom.{m}_spawn_egg', (f'Huevo de {pair[0]}', f'{pair[1]} Spawn Egg'))
    for k, pair in STAGES.items(): put(f'stage.witherbloom.{k}', pair)
    put('itemGroup.witherbloom', ('Witherbloom', 'Witherbloom'))
    put('message.witherbloom.fallen', ('%s cayó ante el virus', '%s fell to the virus'))
    put('effect.witherbloom.marchitez', ('Marchitez', 'Withering')); put('effect.witherbloom.vulnerable', ('Vulnerable', 'Vulnerable'))
    jdump('lang/es_es.json', es); jdump('lang/en_us.json', en)

# ------------------------------------------------------------------ ejecucion
def run():
    for name, fn in ITEMS.items():
        img = fn(); finish_icon(img); save(img, f'textures/item/{name}.png')
        jdump(f'models/item/{name}.json', {'parent': 'minecraft:item/handheld' if name in
              ('estoque_de_reja', 'daga_de_eco', 'hacha_de_hueso_negro', 'guadana_de_wither', 'lanza_de_asta', 'baston_de_plasma', 'jeringa_de_antidoto',
               'pico_sordo', 'podadora_de_zarza', 'pala_de_escombro', 'azada_purificadora', 'tijeras_de_cristal') else 'minecraft:item/generated',
              'textures': {'layer0': f'witherbloom:item/{name}'}})
    for pull in (None, 0, 1, 2):
        img = arco(pull); finish_icon(img)
        nm = 'arco_viral' if pull is None else f'arco_viral_pulling_{pull}'
        save(img, f'textures/item/{nm}.png')
        jdump(f'models/item/{nm}.json', {'parent': 'minecraft:item/bow', 'textures': {'layer0': f'witherbloom:item/{nm}'}} | (
            {'overrides': [{'predicate': {'pulling': 1}, 'model': 'witherbloom:item/arco_viral_pulling_0'},
                           {'predicate': {'pulling': 1, 'pull': 0.65}, 'model': 'witherbloom:item/arco_viral_pulling_1'},
                           {'predicate': {'pulling': 1, 'pull': 0.9}, 'model': 'witherbloom:item/arco_viral_pulling_2'}]} if pull is None else {}))
    for s, spec in SETS.items():
        armor_layers(s, spec)
        for p in HAS[s]:
            save(armor_icon(p, spec), f'textures/item/{s}_{p}.png')
            jdump(f'models/item/{s}_{p}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': f'witherbloom:item/{s}_{p}'}})
    for b in BLOCKS:
        save(block_tex(b), f'textures/block/{b}.png')
        jdump(f'models/block/{b}.json', {'parent': 'minecraft:block/cube_all', 'textures': {'all': f'witherbloom:block/{b}'}})
        jdump(f'blockstates/{b}.json', {'variants': {'': {'model': f'witherbloom:block/{b}'}}})
        jdump(f'models/item/{b}.json', {'parent': f'witherbloom:block/{b}'})
    for m in MOB_NAMES:
        jdump(f'models/item/{m}_spawn_egg.json', {'parent': 'minecraft:item/template_spawn_egg'})
    effect_icons(); lang()
    print('items', len(ITEMS), '| sets', len(SETS), '| bloques', len(BLOCKS))

if __name__ == '__main__':
    run()
