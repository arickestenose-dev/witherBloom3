# Witherbloom (Forge 1.20.1)

Mod basado en el PDF "Bestiario completo". Este paquete es la **fase 1** del proyecto original, reparada y con la parte visual añadida.

## Compilar
1. Descarga el MDK de Forge 1.20.1 (47.3.0) de files.minecraftforge.net y copia de él `gradlew`, `gradlew.bat` y la carpeta `gradle/` a esta carpeta.
2. `./gradlew build` (necesita JDK 17). Para probar: `./gradlew runClient`.
3. **Este código no se ha compilado todavía** (el entorno donde se escribió no tiene acceso a Forge). Si Gradle da errores, pásalos tal cual y se corrigen.

## Regenerar texturas y modelos
`python3 tools/gen_mobs.py` y `python3 tools/gen_items.py` (necesitan Pillow). Cada mob se define una sola vez en `tools/gen_mobs.py`
(cajas + colores + animación); el mismo dato pinta la textura y genera `GeneratedModels.java`, así modelo y textura no se desalinean.
Para añadir un mob con modelo propio: una entrada en `MOBS`, la clase en `entity/`, el registro en `ModEntities`/`ModBusEvents`/`ModItems` (huevo) y el nombre en `MOB_NAMES`.
Los jefes extienden `BossMob` (barra de jefe, fases por % de vida, recompensas).

## Estado de los mobs
| Nivel | Hecho | Pendiente |
|---|---|---|
| 0 Superficie | **Completo (7/7):** Chinche Carmesí, Antena Viva, Hinchado, Suplantador, Hiena Escarlata, Esqueleto Marchito, Guardián de la Reja (jefe, 2 fases) | — |
| 1 Minas | Topo Ciego, Mena Mímica, Capataz Micelio, Sanguijuela Cegadora (4/8) | Osario, Minero Marchito, Ciempiés de Rieles, Taladro Vivo (jefe) |
| 2 Invernadero | — | los 10 |
| 3 Cámaras de Cultivo | — | los 9 |
| 4 La Grieta | — | los 16 y la dimensión |
| 5 El Núcleo | — | los 8 y el Apex |

## Notas de diseño
- "Daño" en el PDF está en corazones (1 corazón = 2 puntos); los mobs y armas siguen esa regla.
- Los materiales son ítems por ahora; los mobs aún no los sueltan (faltan tablas de botín) ni hay recetas.
- Manto de Eco es capucha + manto y el Casco Diagnóstico una sola pieza; el resto de sets pide las 4 piezas.
