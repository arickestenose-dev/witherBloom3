package com.witherbloom.block;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Cerca de el, tu infeccion baja 1 por segundo (radio 5). Usa ticks programados: sin BlockEntity. */
public class AntidotoBlock extends Block {
    public static final int RADIUS = 5;

    public AntidotoBlock(Properties props) { super(props); }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        if (!level.isClientSide) level.scheduleTick(pos, this, 20);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        for (Player p : level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(RADIUS))) {
            InfectionHelper.reduce(p, 1.0F);
        }
        level.scheduleTick(pos, this, 20);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(6) == 0) {
            level.addParticle(ParticleTypes.HAPPY_VILLAGER,
                    pos.getX() + random.nextDouble(), pos.getY() + 1.0D, pos.getZ() + random.nextDouble(), 0, 0.02D, 0);
        }
    }
}
