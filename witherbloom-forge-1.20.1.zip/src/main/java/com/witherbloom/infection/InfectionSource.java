package com.witherbloom.infection;

/** Cualquier entidad que sume infeccion al jugador cuando le hace dano (cuerpo a cuerpo o con proyectiles). */
public interface InfectionSource {
    float infectionOnHit();
}
