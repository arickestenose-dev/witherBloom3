package com.witherbloom.infection;

import com.witherbloom.init.ModCaps;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class InfectionProvider implements ICapabilitySerializable<CompoundTag> {
    private final InfectionData data = new InfectionData();
    private final LazyOptional<InfectionData> optional = LazyOptional.of(() -> data);

    @Override
    public <T> @NotNull LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        return cap == ModCaps.INFECTION ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putFloat("infection", data.get());
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        data.set(tag.getFloat("infection"));
    }

    public void invalidate() { optional.invalidate(); }
}
