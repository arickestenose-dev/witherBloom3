package com.witherbloom.infection;

public class InfectionData {
    private float value;

    public float get() { return value; }

    public void set(float v) { this.value = Math.max(0.0F, Math.min(100.0F, v)); }
}
