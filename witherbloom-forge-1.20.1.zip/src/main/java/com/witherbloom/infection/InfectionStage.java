package com.witherbloom.infection;

import net.minecraft.network.chat.Component;

/** Etapas del PDF: ESPORA 0-24, PORTADOR 25-49, COLONIA 50-74, APEX 75-99, CAIDA 100. */
public enum InfectionStage {
    ESPORA(0, "espora"),
    PORTADOR(25, "portador"),
    COLONIA(50, "colonia"),
    APEX(75, "apex"),
    CAIDA(100, "caida");

    public final int threshold;
    public final String key;

    InfectionStage(int threshold, String key) { this.threshold = threshold; this.key = key; }

    public static InfectionStage of(float value) {
        InfectionStage result = ESPORA;
        for (InfectionStage s : values()) if (value >= s.threshold) result = s;
        return result;
    }

    public boolean atLeast(InfectionStage other) { return this.ordinal() >= other.ordinal(); }

    public Component displayName() { return Component.translatable("stage.witherbloom." + key); }
}
