package com.witherbloom.init;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Witherbloom.MODID);

    public static final RegistryObject<EntityType<ChincheCarmesi>> CHINCHE = ENTITIES.register("chinche_carmesi",
            () -> EntityType.Builder.of(ChincheCarmesi::new, MobCategory.MONSTER).sized(0.4F, 0.3F).clientTrackingRange(8).build("chinche_carmesi"));
    public static final RegistryObject<EntityType<AntenaViva>> ANTENA = ENTITIES.register("antena_viva",
            () -> EntityType.Builder.of(AntenaViva::new, MobCategory.MONSTER).sized(0.9F, 1.8F).clientTrackingRange(10).build("antena_viva"));
    public static final RegistryObject<EntityType<Hinchado>> HINCHADO = ENTITIES.register("hinchado",
            () -> EntityType.Builder.of(Hinchado::new, MobCategory.MONSTER).sized(1.0F, 2.2F).clientTrackingRange(10).build("hinchado"));
    public static final RegistryObject<EntityType<HienaEscarlata>> HIENA = ENTITIES.register("hiena_escarlata",
            () -> EntityType.Builder.of(HienaEscarlata::new, MobCategory.MONSTER).sized(0.7F, 0.9F).clientTrackingRange(8).build("hiena_escarlata"));
    public static final RegistryObject<EntityType<Suplantador>> SUPLANTADOR = ENTITIES.register("suplantador",
            () -> EntityType.Builder.of(Suplantador::new, MobCategory.MONSTER).sized(0.6F, 1.8F).clientTrackingRange(10).build("suplantador"));
    public static final RegistryObject<EntityType<GuardianDeLaReja>> GUARDIAN = ENTITIES.register("guardian_de_la_reja",
            () -> EntityType.Builder.of(GuardianDeLaReja::new, MobCategory.MONSTER).sized(1.6F, 2.8F).clientTrackingRange(16).build("guardian_de_la_reja"));
    public static final RegistryObject<EntityType<TopoCiego>> TOPO = ENTITIES.register("topo_ciego",
            () -> EntityType.Builder.of(TopoCiego::new, MobCategory.MONSTER).sized(0.9F, 0.8F).clientTrackingRange(8).build("topo_ciego"));
    public static final RegistryObject<EntityType<MenaMimica>> MENA = ENTITIES.register("mena_mimica",
            () -> EntityType.Builder.of(MenaMimica::new, MobCategory.MONSTER).sized(1.0F, 1.0F).clientTrackingRange(8).build("mena_mimica"));
    public static final RegistryObject<EntityType<CapatazMicelio>> CAPATAZ = ENTITIES.register("capataz_micelio",
            () -> EntityType.Builder.of(CapatazMicelio::new, MobCategory.MONSTER).sized(1.2F, 2.0F).clientTrackingRange(10).build("capataz_micelio"));
    public static final RegistryObject<EntityType<SanguijuelaCegadora>> SANGUIJUELA = ENTITIES.register("sanguijuela_cegadora",
            () -> EntityType.Builder.of(SanguijuelaCegadora::new, MobCategory.MONSTER).sized(0.4F, 0.6F).clientTrackingRange(8).build("sanguijuela_cegadora"));
    public static final RegistryObject<EntityType<EsqueletoMarchito>> ESQUELETO = ENTITIES.register("esqueleto_marchito",
            () -> EntityType.Builder.of(EsqueletoMarchito::new, MobCategory.MONSTER).sized(0.6F, 1.99F).clientTrackingRange(8).build("esqueleto_marchito"));
}
