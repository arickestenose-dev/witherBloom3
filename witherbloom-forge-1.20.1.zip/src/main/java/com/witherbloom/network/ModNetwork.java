package com.witherbloom.network;

import com.witherbloom.Witherbloom;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Witherbloom.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private ModNetwork() {}

    public static void init() {
        CHANNEL.registerMessage(0, SyncInfectionPacket.class, SyncInfectionPacket::encode,
                SyncInfectionPacket::decode, SyncInfectionPacket::handle);
    }
}
