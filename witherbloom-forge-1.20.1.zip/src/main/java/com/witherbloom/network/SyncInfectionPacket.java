package com.witherbloom.network;

import com.witherbloom.client.ClientInfection;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Infeccion de un jugador (por id de entidad). Se envia a el mismo y a quien lo esta viendo (Casco Diagnostico). */
public record SyncInfectionPacket(int entityId, float value) {
    public static void encode(SyncInfectionPacket m, FriendlyByteBuf b) { b.writeVarInt(m.entityId); b.writeFloat(m.value); }
    public static SyncInfectionPacket decode(FriendlyByteBuf b) { return new SyncInfectionPacket(b.readVarInt(), b.readFloat()); }
    public static void handle(SyncInfectionPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientInfection.set(m.entityId, m.value));
        ctx.get().setPacketHandled(true);
    }
}
