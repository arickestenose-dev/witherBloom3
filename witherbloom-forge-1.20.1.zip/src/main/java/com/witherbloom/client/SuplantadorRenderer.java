package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.witherbloom.Witherbloom;
import com.witherbloom.entity.Suplantador;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/**
 * Suplantador: se dibuja con la skin del companero que imita (modelo ancho o delgado segun esa skin).
 * Una vez revelado usa su propia textura de sculk.
 */
public class SuplantadorRenderer extends MobRenderer<Suplantador, PlayerModel<Suplantador>> {
    private static final ResourceLocation REVEALED = new ResourceLocation(Witherbloom.MODID, "textures/entity/suplantador_revelado.png");
    private final PlayerModel<Suplantador> wide;
    private final PlayerModel<Suplantador> slim;

    public SuplantadorRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.wide = this.model;
        this.slim = new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER_SLIM), true);
    }

    private static boolean isSlim(UUID id) {
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        var info = conn == null ? null : conn.getPlayerInfo(id);
        return info != null && "slim".equals(info.getModelName());
    }

    @Override
    public void render(Suplantador e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buf, int light) {
        this.model = !e.revealed() && e.mimic().map(SuplantadorRenderer::isSlim).orElse(false) ? slim : wide;
        super.render(e, yaw, partialTick, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(Suplantador e) {
        if (e.revealed() || e.mimic().isEmpty()) return REVEALED;
        UUID id = e.mimic().get();
        ClientPacketListener conn = Minecraft.getInstance().getConnection();
        var info = conn == null ? null : conn.getPlayerInfo(id);
        return info != null ? info.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(id);
    }
}
