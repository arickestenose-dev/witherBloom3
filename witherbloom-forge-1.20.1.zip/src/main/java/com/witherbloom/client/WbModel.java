package com.witherbloom.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.witherbloom.entity.ToggleParts;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

import java.util.HashMap;
import java.util.Map;

public class WbModel<T extends Entity> extends EntityModel<T> {
    private final ModelPart root;
    private final ModelSpec spec;
    private final Map<String, ModelPart> parts = new HashMap<>();

    public WbModel(ModelPart root, ModelSpec spec) {
        this.root = root;
        this.spec = spec;
        // Las partes se indican con ruta ("head/snout") para soportar jerarquia.
        for (String path : spec.parts()) {
            ModelPart p = root;
            for (String seg : path.split("/")) p = p.getChild(seg);
            parts.put(path, p);
        }
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        for (ModelPart p : parts.values()) p.resetPose();
        for (String name : spec.looks()) {
            ModelPart p = parts.get(name);
            p.yRot += headYaw * Mth.DEG_TO_RAD;
            p.xRot += headPitch * Mth.DEG_TO_RAD;
        }
        for (ModelSpec.Swing s : spec.swings()) {
            add(parts.get(s.part()), s.axis(), Mth.cos(limbSwing * s.speed() + s.phase()) * s.amp() * limbSwingAmount);
        }
        for (ModelSpec.Idle i : spec.idles()) {
            add(parts.get(i.part()), i.axis(), Mth.sin(age * i.speed()) * i.amp());
        }
        if (entity instanceof ToggleParts tp) {
            for (Map.Entry<String, ModelPart> en : parts.entrySet()) {
                String key = en.getKey();
                en.getValue().visible = tp.showPart(key.substring(key.lastIndexOf('/') + 1));
            }
        }
    }

    private static void add(ModelPart p, char axis, float v) {
        switch (axis) {
            case 'x' -> p.xRot += v;
            case 'y' -> p.yRot += v;
            default -> p.zRot += v;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
