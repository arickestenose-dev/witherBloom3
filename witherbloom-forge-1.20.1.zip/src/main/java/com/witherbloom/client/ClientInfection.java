package com.witherbloom.client;

import java.util.HashMap;
import java.util.Map;

/** Infeccion conocida por el cliente, por id de entidad. Sin clases de cliente: es seguro cargarla en el servidor. */
public final class ClientInfection {
    private static final Map<Integer, Float> VALUES = new HashMap<>();
    private ClientInfection() {}

    public static void set(int entityId, float value) { VALUES.put(entityId, value); }
    public static float get(int entityId) { return VALUES.getOrDefault(entityId, 0.0F); }
    public static void clear() { VALUES.clear(); }
}
