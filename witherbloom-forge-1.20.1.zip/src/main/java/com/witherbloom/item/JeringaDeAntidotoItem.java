package com.witherbloom.item;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;

/** Quita 20 de infeccion a un aliado (clic derecho) o a ti mismo (agachado + clic derecho). */
public class JeringaDeAntidotoItem extends SwordItem {
    public static final float CURE = 20.0F;

    public JeringaDeAntidotoItem(Tier tier, int dmg, float speed, Properties props) { super(tier, dmg, speed, props); }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player user, LivingEntity target, InteractionHand hand) {
        if (target instanceof Player ally) {
            if (!user.level().isClientSide) {
                InfectionHelper.reduce(ally, CURE);
                inject(stack, user, hand);
            }
            return InteractionResult.sidedSuccess(user.level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player user, InteractionHand hand) {
        ItemStack stack = user.getItemInHand(hand);
        if (!user.isShiftKeyDown()) return InteractionResultHolder.pass(stack);
        if (!level.isClientSide) {
            InfectionHelper.reduce(user, CURE);
            inject(stack, user, hand);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private void inject(ItemStack stack, Player user, InteractionHand hand) {
        user.level().playSound(null, user.blockPosition(), SoundEvents.BREWING_STAND_BREW, SoundSource.PLAYERS, 1.0F, 1.4F);
        user.getCooldowns().addCooldown(this, 20);
        stack.hurtAndBreak(1, user, p -> p.broadcastBreakEvent(hand));
    }
}
