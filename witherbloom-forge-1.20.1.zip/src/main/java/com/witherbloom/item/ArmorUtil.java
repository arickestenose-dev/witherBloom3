package com.witherbloom.item;

import com.witherbloom.init.ModArmorMaterials;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;

public final class ArmorUtil {
    private ArmorUtil() {}

    /** El efecto de cada armadura solo se activa con el set completo (todas las piezas que existen para ese set). */
    public static boolean hasSet(LivingEntity entity, ModArmorMaterials material) {
        for (ArmorItem.Type type : material.pieces) {
            ItemStack stack = entity.getItemBySlot(type.getSlot());
            if (!(stack.getItem() instanceof ArmorItem armor) || armor.getMaterial() != material) return false;
        }
        return true;
    }
}
