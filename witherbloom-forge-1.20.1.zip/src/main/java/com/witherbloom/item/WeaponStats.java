package com.witherbloom.item;

/**
 * Dano de armas en CORAZONES, tal como lo da el PDF (1 corazon = 2 pv). Ajusta aqui para rebalancear.
 * El atributo de item suma 1 del jugador, por eso se resta 1.
 */
public final class WeaponStats {
    private WeaponStats() {}

    public static final float ESTOQUE = 6, DAGA = 4, ARCO = 6, HACHA = 8, GUADANA = 7, LANZA = 7, BASTON = 9, JERINGA = 2;

    public static int sword(float hearts) { return Math.round(hearts * 2.0F - 1.0F); }

    public static float axe(float hearts) { return hearts * 2.0F - 1.0F; }

    public static float hp(float hearts) { return hearts * 2.0F; }
}
