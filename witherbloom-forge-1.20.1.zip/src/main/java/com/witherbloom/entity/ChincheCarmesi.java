package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-01 Chinche Carmesi. Se pega a la espalda del jugador y suma +1 infeccion cada 2 s.
 * Para sacudirla: correr y girar el cuerpo ~2 s. Un companero puede golpearla; el fuego y el barrido tambien.
 */
public class ChincheCarmesi extends WitherbloomMob {
    private Player host;
    private int attachedTicks;
    private float lastYaw;
    private float spin;
    private int spinWindow;

    public ChincheCarmesi(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 4.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.42D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 16.0D);
    }

    @Override protected int packMin() { return 5; }
    @Override protected int packMax() { return 7; }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new LeapAtTargetGoal(this, 0.35F));
    }

    /** La succion se da por el temporizador de adherencia, no por golpe. */
    @Override public float infectionOnHit() { return 0.0F; }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && host == null && target instanceof Player p && !p.isCreative()) attach(p);
        return hit;
    }

    private void attach(Player p) {
        this.host = p;
        this.attachedTicks = 0;
        this.lastYaw = p.getYRot();
        this.spin = 0;
        this.spinWindow = 0;
        setNoGravity(true);
        this.noPhysics = true;
    }

    private void detach(boolean shaken) {
        this.host = null;
        setNoGravity(false);
        this.noPhysics = false;
        if (shaken) setDeltaMovement((random.nextDouble() - 0.5D) * 0.8D, 0.35D, (random.nextDouble() - 0.5D) * 0.8D);
    }

    @Override
    public void tick() {
        super.tick();
        if (host == null) return;
        if (!host.isAlive() || host.isRemoved() || host.level() != level()) {
            detach(false);
            return;
        }
        Vec3 look = host.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0D, look.z).normalize();
        moveTo(host.getX() - flat.x * 0.45D, host.getY() + host.getBbHeight() * 0.6D, host.getZ() - flat.z * 0.45D, host.getYRot(), 0.0F);
        setDeltaMovement(Vec3.ZERO);

        if (level().isClientSide) return;
        attachedTicks++;
        if (attachedTicks % 40 == 0) InfectionHelper.add(host, 1.0F);

        // Sacudida: correr + girar >= 270 grados en una ventana de 2 s.
        float yaw = host.getYRot();
        if (host.isSprinting()) spin += Mth.degreesDifferenceAbs(yaw, lastYaw);
        lastYaw = yaw;
        if (++spinWindow >= 40) {
            if (spin >= 270.0F) detach(true);
            spin = 0;
            spinWindow = 0;
        }
    }

    @Override
    public boolean isPushable() { return host == null && super.isPushable(); }
}
