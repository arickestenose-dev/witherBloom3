package com.witherbloom.entity;

/** Entidades que ocultan partes del modelo segun su estado (p. ej. antenas rotas). */
public interface ToggleParts {
    boolean showPart(String partName);
}
