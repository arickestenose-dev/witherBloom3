package com.witherbloom.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Jefes y minijefes: barra de jefe, fases por porcentaje de vida y recompensas fijas. */
public abstract class BossMob extends WitherbloomMob {
    private final ServerBossEvent bar;
    private int lastPhase = 0;

    protected BossMob(EntityType<? extends Monster> type, Level level, BossEvent.BossBarColor color) {
        super(type, level);
        this.bar = new ServerBossEvent(Component.translatable(type.getDescriptionId()), color, BossEvent.BossBarOverlay.PROGRESS);
        this.xpReward = 60;
        setPersistenceRequired();
    }

    /** Umbrales de vida (0..1) en orden descendente. {0.55} = fase 0 hasta 55%, fase 1 despues. */
    protected abstract float[] phaseSplits();
    protected abstract List<ItemStack> rewards();
    protected void onPhaseChange(int phase) {}

    public int phase() {
        float ratio = getHealth() / getMaxHealth();
        int p = 0;
        for (float s : phaseSplits()) if (ratio <= s) p++;
        return p;
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bar.removePlayer(p); }
    @Override public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bar.setName(getDisplayName());
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bar.setProgress(Math.max(0.0F, getHealth() / getMaxHealth()));
        int p = phase();
        if (p != lastPhase) {
            lastPhase = p;
            if (level() instanceof ServerLevel sl) {
                sl.playSound(null, blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.8F, 1.4F);
                sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + getBbHeight() / 2, getZ(), 6, 1.0D, 1.0D, 1.0D, 0.0D);
            }
            onPhaseChange(p);
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        for (ItemStack stack : rewards()) spawnAtLocation(stack);
    }
}
