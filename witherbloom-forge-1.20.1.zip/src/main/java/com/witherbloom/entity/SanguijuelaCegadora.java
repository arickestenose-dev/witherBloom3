package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-19 Sanguijuela Cegadora. Cuelga del techo y cae sobre tu cabeza: oscurece la pantalla, bebe 1 corazon cada 4 s
 * y suma +1 infeccion cada 3 s. Se sacude agachandote 5 veces seguidas; una antorcha en el techo la ahuyenta.
 */
public class SanguijuelaCegadora extends WitherbloomMob {
    private boolean hanging = true, searched;
    private Player host;
    private int attachedTicks, sneaks, sneakWindow;
    private boolean wasSneaking;

    public SanguijuelaCegadora(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D)
                .add(Attributes.ATTACK_DAMAGE, 2.0D)
                .add(Attributes.FOLLOW_RANGE, 12.0D);
    }

    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 0.0F; }
    @Override public boolean isPushable() { return host == null && !hanging && super.isPushable(); }

    private boolean torchNear() {
        BlockPos c = blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-3, -1, -3), c.offset(3, 3, 3))) {
            var st = level().getBlockState(p);
            if (st.is(Blocks.TORCH) || st.is(Blocks.WALL_TORCH) || st.is(Blocks.LANTERN) || st.is(Blocks.SOUL_TORCH)) return true;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (hanging) { tickHanging(); return; }
        if (host == null) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(0.6D, 1.0D, 0.6D), pl -> pl.isAlive() && !pl.isCreative())) {
                attach(p);
                break;
            }
            return;
        }
        tickAttached();
    }

    private void tickHanging() {
        setNoGravity(true);
        setDeltaMovement(Vec3.ZERO);
        if (!searched) {
            searched = true;
            for (int up = 1; up <= 10; up++) {
                BlockPos above = blockPosition().above(up);
                if (!level().getBlockState(above).isAir()) { setPos(getX(), above.getY() - getBbHeight(), getZ()); return; }
            }
            hanging = false; // sin techo cerca: se comporta como un mob normal
            setNoGravity(false);
            return;
        }
        if (tickCount % 5 != 0 || torchNear()) return;
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(1.6D, 10.0D, 1.6D),
                pl -> pl.isAlive() && !pl.isCreative() && pl.getY() < getY() && hasLineOfSight(pl))) {
            hanging = false;
            setNoGravity(false);
            return;
        }
    }

    private void attach(Player p) {
        host = p; attachedTicks = 0; sneaks = 0; sneakWindow = 0; wasSneaking = p.isShiftKeyDown();
        setNoGravity(true);
        this.noPhysics = true;
    }

    private void detach() {
        host = null;
        hanging = false;
        noPhysics = false;
        setNoGravity(false);
        setDeltaMovement((random.nextDouble() - 0.5D) * 0.6D, 0.3D, (random.nextDouble() - 0.5D) * 0.6D);
    }

    private void tickAttached() {
        if (!host.isAlive() || host.level() != level()) { detach(); return; }
        moveTo(host.getX(), host.getEyeY() - 0.15D, host.getZ(), host.getYRot(), 0.0F);
        setDeltaMovement(Vec3.ZERO);
        attachedTicks++;

        if (attachedTicks % 20 == 0) host.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, false, false));
        if (attachedTicks % 80 == 0) host.hurt(damageSources().mobAttack(this), 2.0F);
        if (attachedTicks % 60 == 0) InfectionHelper.add(host, 1.0F);

        // Sacudirla: agacharse 5 veces seguidas (en 5 s).
        boolean sn = host.isShiftKeyDown();
        if (sn && !wasSneaking) sneaks++;
        wasSneaking = sn;
        if (++sneakWindow > 100) { sneakWindow = 0; sneaks = 0; }
        if (sneaks >= 5) detach();
    }
}
