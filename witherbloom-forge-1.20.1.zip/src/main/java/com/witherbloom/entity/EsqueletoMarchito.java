package com.witherbloom.entity;

import com.witherbloom.infection.InfectionSource;
import com.witherbloom.init.ModEffects;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * ESP-36 Esqueleto Marchito (linaje Wither). Tajo negro: Marchitez 4 s. Flecha negra: Marchitez 3 s.
 * Huesos sueltos: al bajar de 50% de vida lanza 3 huesos en abanico.
 * Los huesos son flechas de 2 pv por ahora; en la fase de pulido pasaran a un proyectil propio.
 */
public class EsqueletoMarchito extends AbstractSkeleton implements InfectionSource {
    private boolean split;

    public EsqueletoMarchito(EntityType<? extends AbstractSkeleton> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override public float infectionOnHit() { return 2.0F; }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.SKELETON_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.SKELETON_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.SKELETON_DEATH; }
    @Override protected SoundEvent getStepSound() { return SoundEvents.SKELETON_STEP; }

    /** Zona de pruebas: no se quema con el sol. */
    @Override public boolean isSunBurnTick() { return false; }

    @Override
    protected AbstractArrow getArrow(ItemStack ammo, float power) {
        AbstractArrow arrow = super.getArrow(ammo, power);
        if (arrow instanceof Arrow a) a.addEffect(new MobEffectInstance(ModEffects.MARCHITEZ.get(), 60));
        return arrow;
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity le) le.addEffect(new MobEffectInstance(ModEffects.MARCHITEZ.get(), 80));
        return hit;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean hurt = super.hurt(source, amount);
        if (hurt && !level().isClientSide && !split && isAlive() && getHealth() <= getMaxHealth() * 0.5F) {
            split = true;
            fanBones();
        }
        return hurt;
    }

    private void fanBones() {
        LivingEntity target = getTarget();
        if (target == null) return;
        Vec3 aim = target.getEyePosition().subtract(getEyePosition()).normalize();
        for (int i = -1; i <= 1; i++) {
            Arrow bone = new Arrow(level(), this);
            Vec3 d = aim.yRot(i * 0.3F);
            bone.shoot(d.x, d.y + 0.05D, d.z, 1.4F, 0.0F);
            bone.setBaseDamage(1.0D);
            bone.pickup = AbstractArrow.Pickup.DISALLOWED;
            level().addFreshEntity(bone);
        }
    }
}
