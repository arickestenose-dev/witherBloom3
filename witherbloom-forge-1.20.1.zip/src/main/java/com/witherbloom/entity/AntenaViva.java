package com.witherbloom.entity;

import com.witherbloom.init.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;

/**
 * ESP-02 Antena Viva. Fija, ojo con 20 bloques de vision.
 * - Pulso de alarma (cada 10 s): mobs a 24 bloques ubican al jugador y ganan +20% de velocidad 8 s. Requiere antenas.
 * - Descarga a 8 bloques: 2 corazones, +2 infeccion.
 * - Las antenas (en lo alto) se rompen con proyectiles y vuelven a crecer en 30 s.
 */
public class AntenaViva extends WitherbloomMob implements ToggleParts {
    private static final EntityDataAccessor<Boolean> ANTENNAE = SynchedEntityData.defineId(AntenaViva.class, EntityDataSerializers.BOOLEAN);

    private int alarmCooldown = 60;
    private int zapCooldown = 20;
    private int regrow;

    public AntenaViva(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ANTENNAE, true);
    }

    public boolean hasAntennae() { return this.entityData.get(ANTENNAE); }

    @Override public boolean showPart(String partName) { return !partName.startsWith("antenna") || hasAntennae(); }

    @Override protected void registerGoals() {} // inmovil: solo observa y descarga
    @Override protected boolean retargets() { return false; }
    @Override public float infectionOnHit() { return 2.0F; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isPushedByFluid() { return false; }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || !(level() instanceof ServerLevel sl)) return;

        if (!hasAntennae() && ++regrow >= 600) {
            this.entityData.set(ANTENNAE, true);
            regrow = 0;
        }
        List<Player> seen = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(20.0D),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator() && hasLineOfSight(p));
        if (seen.isEmpty()) return;
        seen.sort(Comparator.comparingDouble(this::distanceToSqr));
        Player target = seen.get(0);
        getLookControl().setLookAt(target, 60.0F, 60.0F);

        if (alarmCooldown > 0) alarmCooldown--;
        if (zapCooldown > 0) zapCooldown--;

        if (hasAntennae() && alarmCooldown <= 0) {
            alarmCooldown = 200;
            sl.playSound(null, blockPosition(), SoundEvents.BELL_BLOCK, SoundSource.HOSTILE, 2.0F, 0.6F);
            for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(24.0D), m -> m != this && m instanceof Enemy)) {
                m.setTarget(target);
                m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 160, 0));
            }
        }
        if (distanceToSqr(target) <= 64.0D && zapCooldown <= 0) {
            zapCooldown = 40;
            target.hurt(damageSources().mobAttack(this), 4.0F);
            Vec3 from = getEyePosition();
            Vec3 d = target.getEyePosition().subtract(from);
            int n = (int) (d.length() * 3);
            for (int i = 0; i <= n; i++) {
                Vec3 p = from.add(d.scale(i / (double) Math.max(n, 1)));
                sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, 0.0D);
            }
            sl.playSound(null, blockPosition(), SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.HOSTILE, 0.4F, 2.0F);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && hasAntennae() && source.getDirectEntity() instanceof Projectile proj
                && proj.getY() >= getY() + getBbHeight() * 0.65D) {
            this.entityData.set(ANTENNAE, false);
            regrow = 0;
            ((ServerLevel) level()).sendParticles(ParticleTypes.CRIT, getX(), getY() + getBbHeight(), getZ(), 12, 0.3D, 0.2D, 0.3D, 0.1D);
        }
        return super.hurt(source, amount);
    }
}
