package com.witherbloom.entity;

import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.infection.InfectionSource;
import com.witherbloom.infection.InfectionStage;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.List;

/**
 * Base de los mobs del virus. Todos pelean de frente (sin mobs de apoyo, como pide el PDF).
 * - Suman infeccion al jugador via InfectionSource (el evento de dano lo aplica tambien a proyectiles).
 * - Los jugadores en etapa APEX son prioridad de objetivo ("los mobs de sculk te priorizan").
 */
public abstract class WitherbloomMob extends Monster implements InfectionSource {
    private static final class PackData implements SpawnGroupData {}

    protected WitherbloomMob(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    /** Cantidad total de miembros cuando aparece por huevo/comando. 0 = en solitario. */
    protected int packMin() { return 0; }
    protected int packMax() { return 0; }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Orden extra de preferencia entre jugadores (por defecto, el mas cercano). */
    protected Comparator<Player> targetOrder() {
        return Comparator.comparingDouble(this::distanceToSqr);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && tickCount % 20 == 0 && retargets()) {
            double range = getAttributeValue(Attributes.FOLLOW_RANGE);
            List<Player> players = level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(range),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator() && hasLineOfSight(p));
            if (!players.isEmpty()) {
                Comparator<Player> order = Comparator
                        .comparing((Player p) -> InfectionHelper.stage(p).atLeast(InfectionStage.APEX) ? 0 : 1)
                        .thenComparing(targetOrder());
                players.sort(order);
                setTarget(players.get(0));
            }
        }
    }

    protected boolean retargets() { return true; }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        data = super.finalizeSpawn(level, difficulty, reason, data, tag);
        if (packMax() > 0 && data == null && level instanceof ServerLevel sl) {
            int total = packMin() + random.nextInt(packMax() - packMin() + 1);
            PackData marker = new PackData();
            for (int i = 1; i < total; i++) {
                if (getType().create(sl) instanceof WitherbloomMob mate) {
                    mate.moveTo(getX() + (random.nextDouble() - 0.5D) * 3.0D, getY(),
                            getZ() + (random.nextDouble() - 0.5D) * 3.0D, random.nextFloat() * 360.0F, 0.0F);
                    mate.finalizeSpawn(level, difficulty, reason, marker, null);
                    sl.addFreshEntity(mate);
                }
            }
            data = marker;
        }
        return data;
    }
}
