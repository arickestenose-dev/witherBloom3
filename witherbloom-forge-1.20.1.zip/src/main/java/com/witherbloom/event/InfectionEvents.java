package com.witherbloom.event;

import com.witherbloom.Witherbloom;
import com.witherbloom.infection.*;
import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.init.ModCaps;
import com.witherbloom.init.ModEffects;
import com.witherbloom.item.ArmorUtil;
import com.witherbloom.network.ModNetwork;
import com.witherbloom.network.SyncInfectionPacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.ICapabilityProvider;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.UUID;

/** Mecanica central: infeccion y sus 5 etapas. */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public class InfectionEvents {
    private static final UUID APEX_HEALTH_UUID = UUID.fromString("0e8f5a52-6a3d-4e0c-a1b4-3c9d7e2f1b88");
    private static final ResourceLocation CAP_ID = new ResourceLocation(Witherbloom.MODID, "infection");

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) {
            InfectionProvider provider = new InfectionProvider();
            e.addCapability(CAP_ID, provider);
            e.addListener(provider::invalidate);
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        if (e.isWasDeath()) return; // al morir, la infeccion se reinicia
        e.getOriginal().reviveCaps();
        e.getOriginal().getCapability(ModCaps.INFECTION).ifPresent(old ->
                e.getEntity().getCapability(ModCaps.INFECTION).ifPresent(now -> now.set(old.get())));
        e.getOriginal().invalidateCaps();
    }

    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e) { syncSelf(e.getEntity()); }
    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e) { syncSelf(e.getEntity()); }
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e) { syncSelf(e.getEntity()); }

    private static void syncSelf(Player p) {
        if (p instanceof ServerPlayer sp) InfectionHelper.sync(sp);
    }

    /** Cuando alguien empieza a ver a otro jugador, recibe su infeccion actual (lo usa el Casco Diagnostico). */
    @SubscribeEvent
    public static void startTracking(PlayerEvent.StartTracking e) {
        if (e.getTarget() instanceof ServerPlayer target && e.getEntity() instanceof ServerPlayer viewer) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                    new SyncInfectionPacket(target.getId(), InfectionHelper.get(target)));
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp) || sp.tickCount % 10 != 0) return;
        float value = InfectionHelper.get(sp);
        InfectionStage stage = InfectionStage.of(value);

        // APEX: -2 corazones maximos temporales.
        AttributeInstance maxHealth = sp.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            boolean apex = stage.atLeast(InfectionStage.APEX);
            AttributeModifier mod = maxHealth.getModifier(APEX_HEALTH_UUID);
            if (apex && mod == null) {
                maxHealth.addTransientModifier(new AttributeModifier(APEX_HEALTH_UUID, "witherbloom_apex", -4.0D, AttributeModifier.Operation.ADDITION));
            } else if (!apex && mod != null) {
                maxHealth.removeModifier(APEX_HEALTH_UUID);
            }
            if (sp.getHealth() > sp.getMaxHealth()) sp.setHealth(sp.getMaxHealth());
        }

        // ESPORA en adelante: particulas moradas, mas densas con la etapa.
        if (value > 0 && sp.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.WITCH, sp.getX(), sp.getY() + 1.0D, sp.getZ(), 1 + stage.ordinal() * 2, 0.35D, 0.5D, 0.35D, 0.01D);
        }
    }

    /** COLONIA+: regeneras la mitad. Marchitez: sin regeneracion natural (curas pequenas se cancelan). */
    @SubscribeEvent
    public static void heal(LivingHealEvent e) {
        LivingEntity entity = e.getEntity();
        if (entity.hasEffect(ModEffects.MARCHITEZ.get()) && e.getAmount() <= 1.0F) {
            e.setCanceled(true);
            return;
        }
        if (entity instanceof Player p && InfectionHelper.stage(p).atLeast(InfectionStage.COLONIA)) {
            e.setAmount(e.getAmount() * 0.5F);
        }
    }

    /** PORTADOR+: los mobs te detectan desde 25% mas lejos. Armadura de Reja: 15% menos. */
    @SubscribeEvent
    public static void visibility(LivingEvent.LivingVisibilityEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        double mod = 1.0D;
        if (InfectionHelper.stage(p).atLeast(InfectionStage.PORTADOR)) mod *= 1.25D;
        if (ArmorUtil.hasSet(p, ModArmorMaterials.REJA)) mod *= 0.85D;
        if (mod != 1.0D) e.modifyVisibility(mod);
    }

    /** Cualquier InfectionSource (mob, flecha disparada por mob...) suma infeccion al danar a un jugador. */
    @SubscribeEvent
    public static void damage(LivingDamageEvent e) {
        if (e.getEntity() instanceof Player p && e.getAmount() > 0.0F && e.getSource().getEntity() instanceof InfectionSource src) {
            InfectionHelper.add(p, src.infectionOnHit());
        }
    }

    /** Traje Hermetico: inmune a Marchitez. */
    @SubscribeEvent
    public static void effectApplicable(MobEffectEvent.Applicable e) {
        MobEffect effect = e.getEffectInstance().getEffect();
        if ((effect == ModEffects.MARCHITEZ.get() || effect == MobEffects.WITHER)
                && ArmorUtil.hasSet(e.getEntity(), ModArmorMaterials.HERMETICO)) {
            e.setResult(Event.Result.DENY);
        }
    }
}
