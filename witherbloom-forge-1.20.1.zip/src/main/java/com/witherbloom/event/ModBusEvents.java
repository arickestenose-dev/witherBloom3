package com.witherbloom.event;

import com.witherbloom.Witherbloom;
import com.witherbloom.entity.*;
import com.witherbloom.infection.InfectionData;
import com.witherbloom.init.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Witherbloom.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.CHINCHE.get(), ChincheCarmesi.createAttributes().build());
        e.put(ModEntities.ANTENA.get(), AntenaViva.createAttributes().build());
        e.put(ModEntities.HINCHADO.get(), Hinchado.createAttributes().build());
        e.put(ModEntities.HIENA.get(), HienaEscarlata.createAttributes().build());
        e.put(ModEntities.ESQUELETO.get(), EsqueletoMarchito.createAttributes().build());
        e.put(ModEntities.SUPLANTADOR.get(), Suplantador.createAttributes().build());
        e.put(ModEntities.GUARDIAN.get(), GuardianDeLaReja.createAttributes().build());
        e.put(ModEntities.TOPO.get(), TopoCiego.createAttributes().build());
        e.put(ModEntities.MENA.get(), MenaMimica.createAttributes().build());
        e.put(ModEntities.CAPATAZ.get(), CapatazMicelio.createAttributes().build());
        e.put(ModEntities.SANGUIJUELA.get(), SanguijuelaCegadora.createAttributes().build());
    }

    @SubscribeEvent
    public static void capabilities(RegisterCapabilitiesEvent e) {
        e.register(InfectionData.class);
    }
}
