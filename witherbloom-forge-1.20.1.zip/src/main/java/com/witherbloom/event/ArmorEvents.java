package com.witherbloom.event;

import com.witherbloom.Witherbloom;
import com.witherbloom.infection.InfectionHelper;
import com.witherbloom.init.ModArmorMaterials;
import com.witherbloom.item.ArmorUtil;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

/**
 * Efectos de set completo. Pendientes para cuando existan los mobs/bloques que los usan (ver README):
 * Perforador (picar en silencio, Topos Ciegos), Zarza (inmunidad a esporas), Manto de Eco (invisible a Ecos y Espirales).
 * Ya activos: Reja, Perforador (derrumbes), Zarza (regeneracion), Latiente, Asta, Neural, Hermetico, Manto (caidas).
 */
@Mod.EventBusSubscriber(modid = Witherbloom.MODID)
public class ArmorEvents {
    private static final UUID HERMETIC_SLOW_UUID = UUID.fromString("7b2d9c14-0f3e-4a85-8e61-d4a1c6b9e305");
    private static final String ASTA_COOLDOWN = "wb_asta_cooldown";

    @SubscribeEvent
    public static void hurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        DamageSource src = e.getSource();

        if (ArmorUtil.hasSet(p, ModArmorMaterials.PERFORADOR) && src.is(DamageTypes.FALLING_BLOCK)) {
            e.setAmount(e.getAmount() * 0.5F);
        }
        if (ArmorUtil.hasSet(p, ModArmorMaterials.NEURAL)
                && (src.is(DamageTypes.MAGIC) || src.is(DamageTypes.INDIRECT_MAGIC) || src.is(DamageTypes.LIGHTNING_BOLT))) {
            e.setAmount(e.getAmount() * 0.7F);
        }
        if (ArmorUtil.hasSet(p, ModArmorMaterials.MANTO_ECO) && src.is(DamageTypes.FALL)) {
            e.setAmount(e.getAmount() * 1.5F);
        }
        if (!p.level().isClientSide && ArmorUtil.hasSet(p, ModArmorMaterials.ASTA)
                && p.getHealth() - e.getAmount() < 8.0F && p.getHealth() > 0.0F) {
            tryAstaTeleport(p, src);
        }
    }

    /** Armadura Latiente: cada golpe recibido baja 1 de infeccion. */
    @SubscribeEvent
    public static void damage(LivingDamageEvent e) {
        if (e.getEntity() instanceof Player p && e.getAmount() > 0.0F && ArmorUtil.hasSet(p, ModArmorMaterials.LATIENTE)) {
            InfectionHelper.reduce(p, 1.0F);
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;

        if (p.tickCount % 20 == 0) {
            AttributeInstance speed = p.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speed != null) {
                boolean hermetic = ArmorUtil.hasSet(p, ModArmorMaterials.HERMETICO);
                AttributeModifier mod = speed.getModifier(HERMETIC_SLOW_UUID);
                if (hermetic && mod == null) {
                    speed.addTransientModifier(new AttributeModifier(HERMETIC_SLOW_UUID, "traje_hermetico", -0.15D, AttributeModifier.Operation.MULTIPLY_TOTAL));
                } else if (!hermetic && mod != null) {
                    speed.removeModifier(HERMETIC_SLOW_UUID);
                }
            }
        }
        // Armadura de Zarza: 1 corazon cada 30 s.
        if (p.tickCount % 600 == 0 && p.getHealth() < p.getMaxHealth() && ArmorUtil.hasSet(p, ModArmorMaterials.ZARZA)) {
            p.heal(2.0F);
        }
    }

    /** Armadura de Asta: una vez cada 60 s te teletransportas 6 bloques al caer a menos de 4 corazones. */
    private static void tryAstaTeleport(Player p, DamageSource src) {
        long now = p.level().getGameTime();
        if (now < p.getPersistentData().getLong(ASTA_COOLDOWN)) return;

        Entity attacker = src.getEntity();
        Vec3 dir = attacker != null
                ? p.position().subtract(attacker.position()).multiply(1.0D, 0.0D, 1.0D)
                : p.getLookAngle().multiply(-1.0D, 0.0D, -1.0D);
        if (dir.lengthSqr() < 1.0E-4D) dir = new Vec3(1.0D, 0.0D, 0.0D);
        dir = dir.normalize();

        for (int dist = 6; dist >= 2; dist--) {
            double dx = dir.x * dist, dz = dir.z * dist;
            AABB moved = p.getBoundingBox().move(dx, 0.0D, dz);
            boolean free = p.level().noCollision(p, moved);
            boolean grounded = !p.level().noCollision(p, moved.move(0.0D, -1.0D, 0.0D));
            if (free && grounded) {
                p.level().playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
                p.teleportTo(p.getX() + dx, p.getY(), p.getZ() + dz);
                p.getPersistentData().putLong(ASTA_COOLDOWN, now + 1200L);
                return;
            }
        }
    }
}
